package com.namrata.labourmanagement.models;

/**
 * Represents a work task assigned to a labourer.
 * Stored in Firebase under: tasks/{taskId}
 */
public class Task {
    private String taskId;
    private String labourerId;
    private String labourerName;
    private String description;
    private String assignedDate;
    private String dueDate;
    private String status; // "Pending", "In Progress", "Completed"

    public Task() {
    }

    public Task(String taskId, String labourerId, String labourerName, String description,
                String assignedDate, String dueDate, String status) {
        this.taskId = taskId;
        this.labourerId = labourerId;
        this.labourerName = labourerName;
        this.description = description;
        this.assignedDate = assignedDate;
        this.dueDate = dueDate;
        this.status = status;
    }

    public String getTaskId() {
        return taskId;
    }

    public void setTaskId(String taskId) {
        this.taskId = taskId;
    }

    public String getLabourerId() {
        return labourerId;
    }

    public void setLabourerId(String labourerId) {
        this.labourerId = labourerId;
    }

    public String getLabourerName() {
        return labourerName;
    }

    public void setLabourerName(String labourerName) {
        this.labourerName = labourerName;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getAssignedDate() {
        return assignedDate;
    }

    public void setAssignedDate(String assignedDate) {
        this.assignedDate = assignedDate;
    }

    public String getDueDate() {
        return dueDate;
    }

    public void setDueDate(String dueDate) {
        this.dueDate = dueDate;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }
}
