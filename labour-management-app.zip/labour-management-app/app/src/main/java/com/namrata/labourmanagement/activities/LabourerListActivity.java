package com.namrata.labourmanagement.activities;

import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.ValueEventListener;
import com.namrata.labourmanagement.R;
import com.namrata.labourmanagement.adapters.LabourerAdapter;
import com.namrata.labourmanagement.models.Labourer;
import com.namrata.labourmanagement.utils.FirebaseHelper;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;

/**
 * Displays all registered labourers in a RecyclerView, backed live by
 * Firebase (ValueEventListener fires immediately with current data, then
 * again every time the data changes -- so the list stays in sync across
 * devices without manual refresh).
 */
public class LabourerListActivity extends AppCompatActivity {

    private RecyclerView recyclerView;
    private LabourerAdapter adapter;
    private final List<Labourer> labourerList = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_labourer_list);

        recyclerView = findViewById(R.id.recyclerViewLabourers);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        adapter = new LabourerAdapter(labourerList);
        recyclerView.setAdapter(adapter);

        FloatingActionButton fabAdd = findViewById(R.id.fabAddLabourer);
        fabAdd.setOnClickListener(v -> showAddLabourerDialog());

        loadLabourers();
    }

    /** Attaches a real-time listener so the list updates whenever Firebase data changes. */
    private void loadLabourers() {
        FirebaseHelper.getLabourersRef().addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot snapshot) {
                labourerList.clear();
                for (DataSnapshot child : snapshot.getChildren()) {
                    Labourer labourer = child.getValue(Labourer.class);
                    if (labourer != null) {
                        labourerList.add(labourer);
                    }
                }
                adapter.notifyDataSetChanged();
            }

            @Override
            public void onCancelled(DatabaseError error) {
                Toast.makeText(LabourerListActivity.this,
                        "Failed to load labourers: " + error.getMessage(),
                        Toast.LENGTH_SHORT).show();
            }
        });
    }

    /** Simple dialog form to add a new labourer -- kept lightweight rather than a full new screen. */
    private void showAddLabourerDialog() {
        View view = getLayoutInflater().inflate(R.layout.dialog_add_labourer, null);
        EditText etName = view.findViewById(R.id.etName);
        EditText etPhone = view.findViewById(R.id.etPhone);
        EditText etRole = view.findViewById(R.id.etRole);
        EditText etWage = view.findViewById(R.id.etWage);

        new AlertDialog.Builder(this)
                .setTitle("Add Labourer")
                .setView(view)
                .setPositiveButton("Save", (dialog, which) -> {
                    String name = etName.getText().toString().trim();
                    String phone = etPhone.getText().toString().trim();
                    String role = etRole.getText().toString().trim();
                    String wageStr = etWage.getText().toString().trim();

                    if (name.isEmpty() || wageStr.isEmpty()) {
                        Toast.makeText(this, "Name and wage are required", Toast.LENGTH_SHORT).show();
                        return;
                    }

                    double wage = Double.parseDouble(wageStr);
                    String id = FirebaseHelper.getLabourersRef().push().getKey();
                    String today = new SimpleDateFormat("yyyy-MM-dd", Locale.getDefault())
                            .format(new Date());

                    Labourer labourer = new Labourer(id, name, phone, role, wage, today);
                    if (id != null) {
                        FirebaseHelper.getLabourersRef().child(id).setValue(labourer)
                                .addOnSuccessListener(unused ->
                                        Toast.makeText(this, "Labourer added", Toast.LENGTH_SHORT).show())
                                .addOnFailureListener(e ->
                                        Toast.makeText(this, "Failed: " + e.getMessage(), Toast.LENGTH_SHORT).show());
                    }
                })
                .setNegativeButton("Cancel", null)
                .show();
    }
}
