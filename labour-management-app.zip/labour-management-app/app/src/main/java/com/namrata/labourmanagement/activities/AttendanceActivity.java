package com.namrata.labourmanagement.activities;

import android.os.Bundle;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.ValueEventListener;
import com.namrata.labourmanagement.R;
import com.namrata.labourmanagement.adapters.AttendanceAdapter;
import com.namrata.labourmanagement.models.Attendance;
import com.namrata.labourmanagement.models.Labourer;
import com.namrata.labourmanagement.utils.FirebaseHelper;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;

/**
 * Lets a supervisor mark today's attendance for every labourer with a
 * single tap per row (present/absent toggle). Each save writes to:
 *   attendance/{today's date}/{labourerId}
 * This structure makes it easy to later query "who was present on 2026-09-20"
 * by just reading attendance/2026-09-20 instead of scanning every record.
 */
public class AttendanceActivity extends AppCompatActivity {

    private RecyclerView recyclerView;
    private AttendanceAdapter adapter;
    private final List<Labourer> labourerList = new ArrayList<>();
    private String todayDate;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_attendance);

        todayDate = new SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(new Date());

        recyclerView = findViewById(R.id.recyclerViewAttendance);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));

        adapter = new AttendanceAdapter(labourerList, this::markAttendance);
        recyclerView.setAdapter(adapter);

        loadLabourers();
    }

    private void loadLabourers() {
        FirebaseHelper.getLabourersRef().addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot snapshot) {
                labourerList.clear();
                for (DataSnapshot child : snapshot.getChildren()) {
                    Labourer labourer = child.getValue(Labourer.class);
                    if (labourer != null) labourerList.add(labourer);
                }
                adapter.notifyDataSetChanged();
            }

            @Override
            public void onCancelled(DatabaseError error) {
                Toast.makeText(AttendanceActivity.this,
                        "Failed to load: " + error.getMessage(), Toast.LENGTH_SHORT).show();
            }
        });
    }

    /** Called by the adapter when a supervisor taps Present/Absent for a labourer. */
    private void markAttendance(Labourer labourer, boolean isPresent) {
        String timestamp = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.getDefault())
                .format(new Date());

        Attendance attendance = new Attendance(
                labourer.getId(), labourer.getName(), todayDate, isPresent, timestamp
        );

        FirebaseHelper.getAttendanceRef()
                .child(todayDate)
                .child(labourer.getId())
                .setValue(attendance)
                .addOnSuccessListener(unused -> Toast.makeText(this,
                        labourer.getName() + " marked " + (isPresent ? "Present" : "Absent"),
                        Toast.LENGTH_SHORT).show())
                .addOnFailureListener(e -> Toast.makeText(this,
                        "Failed: " + e.getMessage(), Toast.LENGTH_SHORT).show());
    }
}
