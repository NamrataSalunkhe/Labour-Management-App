package com.namrata.labourmanagement.models;

/**
 * Represents a single day's attendance record for one labourer.
 * Stored in Firebase under: attendance/{date}/{labourerId}
 */
public class Attendance {
    private String labourerId;
    private String labourerName;
    private String date;       // format: yyyy-MM-dd
    private boolean isPresent;
    private String markedAt;   // timestamp string, for audit purposes

    public Attendance() {
    }

    public Attendance(String labourerId, String labourerName, String date,
                       boolean isPresent, String markedAt) {
        this.labourerId = labourerId;
        this.labourerName = labourerName;
        this.date = date;
        this.isPresent = isPresent;
        this.markedAt = markedAt;
    }

    public String getLabourerId() {
        return labourerId;
    }

    public void setLabourerId(String labourerId) {
        this.labourerId = labourerId;
    }

    public String getLabourerName() {
        return labourerName;
    }

    public void setLabourerName(String labourerName) {
        this.labourerName = labourerName;
    }

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }

    public boolean isPresent() {
        return isPresent;
    }

    public void setPresent(boolean present) {
        isPresent = present;
    }

    public String getMarkedAt() {
        return markedAt;
    }

    public void setMarkedAt(String markedAt) {
        this.markedAt = markedAt;
    }
}
