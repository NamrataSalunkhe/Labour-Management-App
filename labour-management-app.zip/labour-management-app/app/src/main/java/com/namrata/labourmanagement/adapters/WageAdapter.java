package com.namrata.labourmanagement.adapters;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.namrata.labourmanagement.R;
import com.namrata.labourmanagement.models.Labourer;

import java.util.List;
import java.util.Map;

/**
 * Displays each labourer's total wage due, computed as:
 *   total_wage = daily_wage_rate * number_of_days_marked_present
 * The days-present count is precomputed in WageManagementActivity and
 * passed in as a Map<labourerId, dayCount> to keep this adapter simple
 * (it only formats and displays, it doesn't touch Firebase directly).
 */
public class WageAdapter extends RecyclerView.Adapter<WageAdapter.ViewHolder> {

    private final List<Labourer> labourers;
    private final Map<String, Integer> presentDaysCount;

    public WageAdapter(List<Labourer> labourers, Map<String, Integer> presentDaysCount) {
        this.labourers = labourers;
        this.presentDaysCount = presentDaysCount;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.item_wage, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        Labourer labourer = labourers.get(position);
        int daysPresent = presentDaysCount.getOrDefault(labourer.getId(), 0);
        double totalWage = labourer.getDailyWage() * daysPresent;

        holder.tvName.setText(labourer.getName());
        holder.tvDaysPresent.setText(daysPresent + " days present");
        holder.tvTotalWage.setText(String.format("Total: ₹%.2f", totalWage));
    }

    @Override
    public int getItemCount() {
        return labourers.size();
    }

    static class ViewHolder extends RecyclerView.ViewHolder {
        TextView tvName, tvDaysPresent, tvTotalWage;

        ViewHolder(View itemView) {
            super(itemView);
            tvName = itemView.findViewById(R.id.tvWageName);
            tvDaysPresent = itemView.findViewById(R.id.tvDaysPresent);
            tvTotalWage = itemView.findViewById(R.id.tvTotalWage);
        }
    }
}
