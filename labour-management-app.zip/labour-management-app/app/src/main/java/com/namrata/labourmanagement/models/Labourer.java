package com.namrata.labourmanagement.models;

/**
 * Represents a labourer registered in the system.
 * This is a plain data model used for both Firebase serialization
 * (Firebase Realtime Database maps JSON objects to these fields automatically)
 * and for passing data between activities/adapters.
 */
public class Labourer {
    private String id;
    private String name;
    private String phoneNumber;
    private String role;       // e.g. "Mason", "Electrician", "Helper"
    private double dailyWage;
    private String joiningDate;

    // Empty constructor required by Firebase for automatic deserialization
    public Labourer() {
    }

    public Labourer(String id, String name, String phoneNumber, String role,
                     double dailyWage, String joiningDate) {
        this.id = id;
        this.name = name;
        this.phoneNumber = phoneNumber;
        this.role = role;
        this.dailyWage = dailyWage;
        this.joiningDate = joiningDate;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getPhoneNumber() {
        return phoneNumber;
    }

    public void setPhoneNumber(String phoneNumber) {
        this.phoneNumber = phoneNumber;
    }

    public String getRole() {
        return role;
    }

    public void setRole(String role) {
        this.role = role;
    }

    public double getDailyWage() {
        return dailyWage;
    }

    public void setDailyWage(double dailyWage) {
        this.dailyWage = dailyWage;
    }

    public String getJoiningDate() {
        return joiningDate;
    }

    public void setJoiningDate(String joiningDate) {
        this.joiningDate = joiningDate;
    }
}
