package com.namrata.labourmanagement.activities;

import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.ValueEventListener;
import com.namrata.labourmanagement.R;
import com.namrata.labourmanagement.adapters.TaskAdapter;
import com.namrata.labourmanagement.models.Labourer;
import com.namrata.labourmanagement.models.Task;
import com.namrata.labourmanagement.utils.FirebaseHelper;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;

/**
 * Lets a supervisor assign work tasks to labourers and track their status
 * (Pending -> In Progress -> Completed). Tapping a task in the list cycles
 * its status, handled inside TaskAdapter.
 */
public class TaskAssignmentActivity extends AppCompatActivity {

    private RecyclerView recyclerView;
    private TaskAdapter adapter;
    private final List<Task> taskList = new ArrayList<>();
    private List<Labourer> labourerList = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_task_assignment);

        recyclerView = findViewById(R.id.recyclerViewTasks);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        adapter = new TaskAdapter(taskList, this::cycleTaskStatus);
        recyclerView.setAdapter(adapter);

        FloatingActionButton fabAdd = findViewById(R.id.fabAddTask);
        fabAdd.setOnClickListener(v -> showAssignTaskDialog());

        loadLabourers();
        loadTasks();
    }

    private void loadLabourers() {
        FirebaseHelper.getLabourersRef().addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot snapshot) {
                labourerList = new ArrayList<>();
                for (DataSnapshot child : snapshot.getChildren()) {
                    Labourer l = child.getValue(Labourer.class);
                    if (l != null) labourerList.add(l);
                }
            }

            @Override
            public void onCancelled(DatabaseError error) {
                // Silently ignore -- if this fails, the dialog will just show an empty list
            }
        });
    }

    private void loadTasks() {
        FirebaseHelper.getTasksRef().addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot snapshot) {
                taskList.clear();
                for (DataSnapshot child : snapshot.getChildren()) {
                    Task task = child.getValue(Task.class);
                    if (task != null) taskList.add(task);
                }
                adapter.notifyDataSetChanged();
            }

            @Override
            public void onCancelled(DatabaseError error) {
                Toast.makeText(TaskAssignmentActivity.this,
                        "Failed to load tasks: " + error.getMessage(), Toast.LENGTH_SHORT).show();
            }
        });
    }

    private void showAssignTaskDialog() {
        if (labourerList.isEmpty()) {
            Toast.makeText(this, "Add a labourer first", Toast.LENGTH_SHORT).show();
            return;
        }

        View view = getLayoutInflater().inflate(R.layout.dialog_assign_task, null);
        Spinner spinnerLabourer = view.findViewById(R.id.spinnerLabourer);
        EditText etDescription = view.findViewById(R.id.etTaskDescription);
        EditText etDueDate = view.findViewById(R.id.etDueDate);

        List<String> names = new ArrayList<>();
        for (Labourer l : labourerList) names.add(l.getName());
        ArrayAdapter<String> spinnerAdapter = new ArrayAdapter<>(
                this, android.R.layout.simple_spinner_dropdown_item, names);
        spinnerLabourer.setAdapter(spinnerAdapter);

        new AlertDialog.Builder(this)
                .setTitle("Assign Task")
                .setView(view)
                .setPositiveButton("Assign", (dialog, which) -> {
                    String description = etDescription.getText().toString().trim();
                    String dueDate = etDueDate.getText().toString().trim();

                    if (description.isEmpty()) {
                        Toast.makeText(this, "Description is required", Toast.LENGTH_SHORT).show();
                        return;
                    }

                    Labourer selected = labourerList.get(spinnerLabourer.getSelectedItemPosition());
                    String taskId = FirebaseHelper.getTasksRef().push().getKey();
                    String today = new SimpleDateFormat("yyyy-MM-dd", Locale.getDefault())
                            .format(new Date());

                    Task task = new Task(taskId, selected.getId(), selected.getName(),
                            description, today, dueDate, "Pending");

                    if (taskId != null) {
                        FirebaseHelper.getTasksRef().child(taskId).setValue(task)
                                .addOnSuccessListener(unused ->
                                        Toast.makeText(this, "Task assigned", Toast.LENGTH_SHORT).show())
                                .addOnFailureListener(e ->
                                        Toast.makeText(this, "Failed: " + e.getMessage(), Toast.LENGTH_SHORT).show());
                    }
                })
                .setNegativeButton("Cancel", null)
                .show();
    }

    /** Cycles a task's status forward: Pending -> In Progress -> Completed -> Pending. */
    private void cycleTaskStatus(Task task) {
        String nextStatus;
        switch (task.getStatus()) {
            case "Pending":
                nextStatus = "In Progress";
                break;
            case "In Progress":
                nextStatus = "Completed";
                break;
            default:
                nextStatus = "Pending";
        }

        FirebaseHelper.getTasksRef().child(task.getTaskId()).child("status")
                .setValue(nextStatus);
    }
}
