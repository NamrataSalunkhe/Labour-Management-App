package com.namrata.labourmanagement.adapters;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.namrata.labourmanagement.R;
import com.namrata.labourmanagement.models.Labourer;

import java.util.List;

/** Binds the labourer list to a RecyclerView -- shows name, role, and wage rate. */
public class LabourerAdapter extends RecyclerView.Adapter<LabourerAdapter.ViewHolder> {

    private final List<Labourer> labourers;

    public LabourerAdapter(List<Labourer> labourers) {
        this.labourers = labourers;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.item_labourer, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        Labourer labourer = labourers.get(position);
        holder.tvName.setText(labourer.getName());
        holder.tvRole.setText(labourer.getRole());
        holder.tvWage.setText(String.format("₹%.2f/day", labourer.getDailyWage()));
        holder.tvPhone.setText(labourer.getPhoneNumber());
    }

    @Override
    public int getItemCount() {
        return labourers.size();
    }

    static class ViewHolder extends RecyclerView.ViewHolder {
        TextView tvName, tvRole, tvWage, tvPhone;

        ViewHolder(View itemView) {
            super(itemView);
            tvName = itemView.findViewById(R.id.tvLabourerName);
            tvRole = itemView.findViewById(R.id.tvLabourerRole);
            tvWage = itemView.findViewById(R.id.tvLabourerWage);
            tvPhone = itemView.findViewById(R.id.tvLabourerPhone);
        }
    }
}
