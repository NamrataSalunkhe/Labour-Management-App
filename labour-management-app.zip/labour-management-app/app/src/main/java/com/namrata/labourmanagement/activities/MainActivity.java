package com.namrata.labourmanagement.activities;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import androidx.appcompat.app.AppCompatActivity;

import com.namrata.labourmanagement.R;

/**
 * Landing screen after login. Shows the three core features as
 * navigation buttons: Attendance, Task Assignment, Wage Management.
 */
public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Button btnAttendance = findViewById(R.id.btnAttendance);
        Button btnTasks = findViewById(R.id.btnTasks);
        Button btnWages = findViewById(R.id.btnWages);
        Button btnLabourers = findViewById(R.id.btnLabourers);

        btnLabourers.setOnClickListener(v ->
            startActivity(new Intent(this, LabourerListActivity.class)));

        btnAttendance.setOnClickListener(v ->
            startActivity(new Intent(this, AttendanceActivity.class)));

        btnTasks.setOnClickListener(v ->
            startActivity(new Intent(this, TaskAssignmentActivity.class)));

        btnWages.setOnClickListener(v ->
            startActivity(new Intent(this, WageManagementActivity.class)));
    }
}
