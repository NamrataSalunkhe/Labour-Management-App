package com.namrata.labourmanagement.utils;

import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

/**
 * Central place for Firebase Realtime Database references.
 * Keeping this in one class avoids scattering raw string paths
 * ("labourers", "attendance", "tasks") across every activity, which
 * would be error-prone (a typo in one place silently breaks a feature).
 */
public class FirebaseHelper {

    private static final FirebaseDatabase database = FirebaseDatabase.getInstance();

    public static DatabaseReference getLabourersRef() {
        return database.getReference("labourers");
    }

    public static DatabaseReference getAttendanceRef() {
        return database.getReference("attendance");
    }

    public static DatabaseReference getTasksRef() {
        return database.getReference("tasks");
    }

    public static DatabaseReference getWagesRef() {
        return database.getReference("wages");
    }
}
