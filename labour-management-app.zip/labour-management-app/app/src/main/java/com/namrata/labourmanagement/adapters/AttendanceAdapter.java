package com.namrata.labourmanagement.adapters;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.namrata.labourmanagement.R;
import com.namrata.labourmanagement.models.Labourer;

import java.util.List;

/**
 * Shows one row per labourer with Present/Absent buttons.
 * The listener interface decouples the adapter from Firebase logic --
 * the adapter only reports "this button was tapped for this labourer",
 * and the hosting Activity decides what to do with that (write to Firebase).
 */
public class AttendanceAdapter extends RecyclerView.Adapter<AttendanceAdapter.ViewHolder> {

    public interface OnAttendanceMarkedListener {
        void onMarked(Labourer labourer, boolean isPresent);
    }

    private final List<Labourer> labourers;
    private final OnAttendanceMarkedListener listener;

    public AttendanceAdapter(List<Labourer> labourers, OnAttendanceMarkedListener listener) {
        this.labourers = labourers;
        this.listener = listener;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.item_attendance, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        Labourer labourer = labourers.get(position);
        holder.tvName.setText(labourer.getName());

        holder.btnPresent.setOnClickListener(v -> listener.onMarked(labourer, true));
        holder.btnAbsent.setOnClickListener(v -> listener.onMarked(labourer, false));
    }

    @Override
    public int getItemCount() {
        return labourers.size();
    }

    static class ViewHolder extends RecyclerView.ViewHolder {
        TextView tvName;
        Button btnPresent, btnAbsent;

        ViewHolder(View itemView) {
            super(itemView);
            tvName = itemView.findViewById(R.id.tvAttendanceName);
            btnPresent = itemView.findViewById(R.id.btnPresent);
            btnAbsent = itemView.findViewById(R.id.btnAbsent);
        }
    }
}
