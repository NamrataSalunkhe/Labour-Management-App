package com.namrata.labourmanagement.activities;

import android.os.Bundle;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.ValueEventListener;
import com.namrata.labourmanagement.R;
import com.namrata.labourmanagement.adapters.WageAdapter;
import com.namrata.labourmanagement.models.Labourer;
import com.namrata.labourmanagement.utils.FirebaseHelper;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Calculates monthly wages by combining each labourer's daily wage rate
 * with their attendance records: total_wage = daily_wage * days_present.
 *
 * This activity reads TWO Firebase nodes (labourers + attendance) and joins
 * them client-side, since Firebase Realtime Database is a NoSQL store and
 * doesn't support SQL-style JOINs -- this pattern (fetch both, combine in
 * code) is the standard approach when working with it.
 */
public class WageManagementActivity extends AppCompatActivity {

    private RecyclerView recyclerView;
    private WageAdapter adapter;
    private final List<Labourer> labourerList = new ArrayList<>();
    private final Map<String, Integer> presentDaysCount = new HashMap<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_wage_management);

        recyclerView = findViewById(R.id.recyclerViewWages);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        adapter = new WageAdapter(labourerList, presentDaysCount);
        recyclerView.setAdapter(adapter);

        loadAttendanceThenLabourers();
    }

    /**
     * Attendance is loaded first (counting present days per labourer id),
     * then labourers are loaded and the adapter is refreshed -- this order
     * ensures wage totals are correct the first time the screen renders,
     * rather than showing zero wages briefly before attendance data arrives.
     */
    private void loadAttendanceThenLabourers() {
        FirebaseHelper.getAttendanceRef().addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dateSnapshot) {
                presentDaysCount.clear();
                for (DataSnapshot dayNode : dateSnapshot.getChildren()) {
                    for (DataSnapshot labourerNode : dayNode.getChildren()) {
                        Boolean isPresent = labourerNode.child("present").getValue(Boolean.class);
                        String labourerId = labourerNode.child("labourerId").getValue(String.class);
                        if (Boolean.TRUE.equals(isPresent) && labourerId != null) {
                            presentDaysCount.merge(labourerId, 1, Integer::sum);
                        }
                    }
                }
                loadLabourers();
            }

            @Override
            public void onCancelled(DatabaseError error) {
                Toast.makeText(WageManagementActivity.this,
                        "Failed to load attendance: " + error.getMessage(),
                        Toast.LENGTH_SHORT).show();
                loadLabourers();
            }
        });
    }

    private void loadLabourers() {
        FirebaseHelper.getLabourersRef().addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot snapshot) {
                labourerList.clear();
                for (DataSnapshot child : snapshot.getChildren()) {
                    Labourer l = child.getValue(Labourer.class);
                    if (l != null) labourerList.add(l);
                }
                adapter.notifyDataSetChanged();
            }

            @Override
            public void onCancelled(DatabaseError error) {
                Toast.makeText(WageManagementActivity.this,
                        "Failed to load labourers: " + error.getMessage(),
                        Toast.LENGTH_SHORT).show();
            }
        });
    }
}
