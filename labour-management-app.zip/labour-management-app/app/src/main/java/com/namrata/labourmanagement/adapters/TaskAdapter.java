package com.namrata.labourmanagement.adapters;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.namrata.labourmanagement.R;
import com.namrata.labourmanagement.models.Task;

import java.util.List;

/** Shows assigned tasks; tapping a row cycles its status via the listener. */
public class TaskAdapter extends RecyclerView.Adapter<TaskAdapter.ViewHolder> {

    public interface OnTaskClickListener {
        void onTaskClick(Task task);
    }

    private final List<Task> tasks;
    private final OnTaskClickListener listener;

    public TaskAdapter(List<Task> tasks, OnTaskClickListener listener) {
        this.tasks = tasks;
        this.listener = listener;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.item_task, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        Task task = tasks.get(position);
        holder.tvLabourerName.setText(task.getLabourerName());
        holder.tvDescription.setText(task.getDescription());
        holder.tvDueDate.setText("Due: " + task.getDueDate());
        holder.tvStatus.setText(task.getStatus());

        holder.itemView.setOnClickListener(v -> listener.onTaskClick(task));
    }

    @Override
    public int getItemCount() {
        return tasks.size();
    }

    static class ViewHolder extends RecyclerView.ViewHolder {
        TextView tvLabourerName, tvDescription, tvDueDate, tvStatus;

        ViewHolder(View itemView) {
            super(itemView);
            tvLabourerName = itemView.findViewById(R.id.tvTaskLabourerName);
            tvDescription = itemView.findViewById(R.id.tvTaskDescription);
            tvDueDate = itemView.findViewById(R.id.tvTaskDueDate);
            tvStatus = itemView.findViewById(R.id.tvTaskStatus);
        }
    }
}
