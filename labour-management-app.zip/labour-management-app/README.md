# Labour Management Android Application

An Android app for construction/site supervisors to manage daily-wage labourers: track attendance, assign tasks, and calculate wages automatically based on days worked.

## Features

1. **Labourer Management** — Add and view labourers with name, phone, role, and daily wage rate.
2. **Attendance Tracking** — Mark each labourer Present/Absent for the day with one tap; stored per date so historical records are queryable.
3. **Task Assignment** — Assign work tasks to specific labourers and track status through Pending → In Progress → Completed.
4. **Wage Management** — Automatically calculates total wages owed per labourer: `daily_wage × days_present`, computed by combining attendance records with wage rates.

## Architecture

- **MVC-ish structure**: `models/` (plain data classes), `activities/` (screens + logic), `adapters/` (RecyclerView binding), `utils/` (Firebase reference helper).
- **Firebase Realtime Database** as backend — chosen over a local SQLite database so a supervisor's phone and, say, an office computer stay in sync automatically, and data survives even if a device is lost.
- **Data model**:
  ```
  labourers/{labourerId}         -> Labourer object
  attendance/{date}/{labourerId} -> Attendance object
  tasks/{taskId}                 -> Task object
  ```
  Attendance is nested by date first because the most common query is "who was present on day X," not "show me all attendance for labourer Y" — the structure is designed around the access pattern, which is the standard approach with a NoSQL database like Firebase Realtime Database (no JOINs, so you design the tree shape around your queries).

## Tech Stack
- Java
- Android SDK (Activities, RecyclerView, Material Components)
- Firebase Realtime Database
- Gradle

## Setup

1. Clone this repo and open it in **Android Studio**.
2. Create a Firebase project at [firebase.google.com](https://firebase.google.com), add an Android app with package name `com.namrata.labourmanagement`, and download the generated `google-services.json` file into the `app/` folder (this file is intentionally not included in the repo since it contains project-specific keys).
3. Enable **Realtime Database** in the Firebase console (start in test mode for development).
4. Sync Gradle and run on an emulator or physical device.

## Screens
*(Add screenshots here once you run it — Main dashboard, Labourer list, Attendance marking, Task assignment, Wage summary.)*

## Possible Improvements
- Add Firebase Authentication so each supervisor logs in separately
- Add monthly wage history/export instead of only current totals
- Push notifications for task deadlines
- Offline support using Firebase's built-in local caching

## Notes on this project
The main design decision worth discussing: wages aren't stored directly — they're *derived* from attendance records + wage rate at read time. This avoids the classic bug of a wage total going stale if a supervisor edits attendance after the fact; the total is always recalculated from source data instead of trusting a cached number.
